import os, json, xbmc, xbmcgui, xbmcaddon, xbmcvfs, time

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
M3U_URL = "https://raw.githubusercontent.com/didicola/ghost-matrix-iptv/main/iptv.m3u"
LOCAL_M3U = os.path.join(PROFILE, "iptv.m3u")

def download_m3u():
    import urllib.request
    try:
        if not os.path.exists(PROFILE):
            os.makedirs(PROFILE)
        req = urllib.request.Request(M3U_URL, headers={'User-Agent': 'GhostMatrix/1.0'})
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        with open(LOCAL_M3U, 'wb') as f:
            f.write(data)
        return True
    except:
        return False

def set_pvr_setting():
    try:
        import xbmcvfs
        settings_path = os.path.join(xbmcvfs.translatePath('special://profile'), 'userdata', 'addon_data', 'pvr.iptvsimple', 'settings.xml')
        os.makedirs(os.path.dirname(settings_path), exist_ok=True)
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<settings version="2">
  <section id="connection">
    <category id="general">
      <group id="3">
        <setting id="m3uUrl" type="string" value="''' + M3U_URL + '''">
          <level>0</level>
          <default></default>
          <control type="editformat" formaturl"/>
        </setting>
        <setting id="m3uPath" type="string" value="">
          <level>0</level>
          <default></default>
        </setting>
        <setting id="m3uPathType" type="integer" value="1">
          <level>0</level>
          <default>1</default>
        </setting>
        <setting id="refreshIntvl" type="integer" value="0">
          <level>0</level>
          <default>0</default>
        </setting>
        <setting id="kodiAddonsAutoUpdate" type="boolean" value="false">
          <level>0</level>
          <default>false</default>
        </setting>
      </group>
    </category>
  </section>
</settings>'''
        with open(settings_path, 'w') as f:
            f.write(xml)
        return True
    except:
        return False

class GhostMatrixMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        pass

monitor = GhostMatrixMonitor()

# Wait for Kodi to fully start
xbmc.sleep(5000)

# Download M3U
dialog = xbmcgui.Dialog()
if download_m3u():
    set_pvr_setting()
    xbmc.log("Ghost Matrix: M3U downloaded and PVR configured", level=xbmc.LOGINFO)
    # Notify user
    notification = xbmcgui.DialogNotification("Ghost Matrix", "4000+ channels installed!", xbmcgui.NOTIFICATION_INFO, 5000)
    notification.show()
else:
    xbmc.log("Ghost Matrix: Failed to download M3U", level=xbmc.LOGERROR)

# Keep running
while not monitor.abortRequested():
    monitor.waitForAbort(3600)
