#!/usr/bin/env python3
import xbmcgui
import xbmcplugin
import xbmc
import xbmcvfs
import os
import sys
import urllib.request
import json
from urllib.parse import urlencode, parse_qsl

# Ghost Matrix runs on the TV itself
class GhostMatrix:
    def __init__(self):
        self.handle = int(sys.argv[1])
        self.base_url = sys.argv[0]
        
        # Categories available
        self.categories = {
            'live': 'Entertainment',
            'movies': 'Movies',
            'sports': 'Sports',
            'news': 'News',
            'kids': 'Kids',
            'music': 'Music',
            'documentary': 'Documentary',
            'education': 'Education',
            'science': 'Science',
            'tech': 'Technology',
            'travel': 'Travel',
            'food': 'Food & Cooking',
            'fashion': 'Fashion',
            'art': 'Art & Culture',
            'history': 'History',
            'nature': 'Nature',
            'animation': 'Animation',
            'comedy': 'Comedy',
            'drama': 'Drama',
            'horror': 'Horror',
            'action': 'Action',
            'adventure': 'Adventure',
            'romance': 'Romance',
            'thriller': 'Thriller',
            'mystery': 'Mystery',
            'scifi': 'Sci-Fi',
            'fantasy': 'Fantasy',
            'western': 'Western',
            'crime': 'Crime',
            'war': 'War',
            'biography': 'Biography',
            'family': 'Family',
            'musical': 'Musical',
            'reality': 'Reality',
            'lifestyle': 'Lifestyle',
            'religious': 'Religious',
        }
    
    def build_url(self, action, category=None):
        params = {'action': action}
        if category:
            params['category'] = category
        return f"{self.base_url}?{urlencode(params)}"
    
    def show_categories(self):
        # Add main menu items
        for cat_id, cat_name in self.categories.items():
            li = xbmcgui.ListItem(f"[B]{cat_name}[/B]")
            li.setArt({'icon': 'DefaultFolder.png'})
            url = self.build_url('category', cat_id)
            xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        
        # Add status
        li = xbmcgui.ListItem("[B]Ghost Matrix Status[/B]")
        li.setArt({'icon': 'DefaultInfo.png'})
        url = self.build_url('status')
        xbmcplugin.addDirectoryItem(self.handle, url, li, True)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_channels(self, category):
        # Fetch channels from iptv-org
        url = f'https://iptv-org.github.io/iptv/categories/{category}.m3u'
        
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            resp = urllib.request.urlopen(req, timeout=15)
            data = resp.read().decode('utf-8', errors='ignore')
            
            lines = data.split('\n')
            i = 0
            while i < len(lines):
                if lines[i].startswith('#EXTINF'):
                    # Parse channel info
                    extinf = lines[i]
                    stream_url = lines[i+1] if i+1 < len(lines) else ''
                    
                    # Extract name
                    name = extinf.split(',')[-1] if ',' in extinf else 'Unknown'
                    
                    # Extract logo
                    logo = ''
                    if 'tvg-logo="' in extinf:
                        logo_start = extinf.find('tvg-logo="') + 10
                        logo_end = extinf.find('"', logo_start)
                        logo = extinf[logo_start:logo_end]
                    
                    # Create list item
                    li = xbmcgui.ListItem(name)
                    if logo:
                        li.setArt({'icon': logo, 'thumb': logo})
                    
                    # Play stream directly
                    url = self.build_url('play', stream_url)
                    xbmcplugin.addDirectoryItem(self.handle, url, li, False)
                    
                    i += 2
                else:
                    i += 1
        
        except Exception as e:
            li = xbmcgui.ListItem(f"Error: {str(e)}")
            xbmcplugin.addDirectoryItem(self.handle, '', li, False)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def play_stream(self, stream_url):
        # Decode the stream URL
        import urllib.parse
        decoded_url = urllib.parse.unquote(stream_url)
        
        # Play the stream
        li = xbmcgui.ListItem(path=decoded_url)
        xbmc.Player().play(decoded_url, li)
    
    def show_status(self):
        # Show Ghost Matrix status
        dialog = xbmcgui.Dialog()
        dialog.ok(
            "EON Ghost Matrix",
            "Status: ONLINE\n"
            "Server: Running on TV\n"
            "Channels: 6,401+\n"
            "Auto-restart: ENABLED\n\n"
            "This addon runs directly on your TV.\n"
            "No phone or computer needed."
        )

# Main entry point
if __name__ == '__main__':
    ghost = GhostMatrix()
    
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action', 'menu')
    
    if action == 'menu':
        ghost.show_categories()
    elif action == 'category':
        ghost.show_channels(params.get('category', 'live'))
    elif action == 'play':
        ghost.play_stream(params.get('category', ''))
    elif action == 'status':
        ghost.show_status()
