Image = ImageFilter = ImageDraw = None
def _lazy(): raise ImportError('PIL stub: image functions disabled')
